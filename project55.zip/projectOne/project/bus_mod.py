from ui.bus_mod_ui import *
from ui.bus_con_ui import *
from ui.bus_list_ui import *
from db.db_list import *
from db.db_mod import *
from PyQt5.QtCore import QCoreApplication
from PyQt5.Qt import QTableWidgetItem, Qt
import sys

app = QtWidgets.QApplication(sys.argv)
MainWindow = QtWidgets.QMainWindow()
ui3 = Ui_buslist()
ui4=Ui_busmod()

id=''
list1=[]

def table(uid):
    global id
    id=uid
    header = ui3.table.horizontalHeader()       
    header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
    header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
    header.setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)
    header.setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)
    header.setSectionResizeMode(4, QtWidgets.QHeaderView.Stretch) 
    
    ui3.table.setRowCount(0)
    
    for row, form in enumerate(select_all(uid)):
        row_position=ui3.table.rowCount()
        ui3.table.insertRow(row_position)        
        for column,value in enumerate(form):
            item = QTableWidgetItem(str(value))
            item.setTextAlignment(Qt.AlignVCenter | Qt.AlignHCenter);
            ui3.table.setItem(row,column,item)
            ui3.table.setEditTriggers(QtWidgets.QTableWidget.NoEditTriggers)
            
    ui3.table.cellClicked.connect(updateMore)
    ui3.ok.clicked.connect(click)
    ui3.cancel.clicked.connect(MainWindow.close)
    
def updateMore():
    lists=[]
    row=ui3.table.currentItem().row()
    for i in range(ui3.table.columnCount()):
        lists.append(ui3.table.item(row, i).text())
    return lists

def click():
    global list1
    i=updateMore()
    lists=select(i,id)
    mod(lists)
    list1=lists

def check():
    msg=''
    money=0
    if ui4.A1.isChecked()==True:
        msg+='A1,'
        money+=10000
    if ui4.A2.isChecked()==True:
        msg+='A2,'
        money+=10000
    if ui4.A3.isChecked()==True:
        msg+='A3,'
        money+=10000
    if ui4.A4.isChecked()==True:
        msg+='A4,'
        money+=10000
    if ui4.B1.isChecked()==True:
        msg+='B1,'
        money+=10000
    if ui4.B2.isChecked()==True:
        msg+='B2,'
        money+=10000
    if ui4.B3.isChecked()==True:
        msg+='B3,'
        money+=10000
    if ui4.B4.isChecked()==True:
        msg+='B4,'
        money+=10000
    if ui4.C1.isChecked()==True:
        msg+='C1,'
        money+=10000
    if ui4.C2.isChecked()==True:
        msg+='C2,'
        money+=10000
    if ui4.C3.isChecked()==True:
        msg+='C3,'
        money+=10000
    if ui4.C4.isChecked()==True:
        msg+='C4,'
        money+=10000
    if ui4.D1.isChecked()==True:
        msg+='D1,'
        money+=10000
    if ui4.D2.isChecked()==True:
        msg+='D2,'
        money+=10000
    if ui4.D3.isChecked()==True:
        msg+='D3,'
        money+=10000
    if ui4.D4.isChecked()==True:
        msg+='D4,'
        money+=10000
    ui4.sit_text.setText('좌석 : '+msg[:9])
    ui4.sit_text_2.setText(msg[9:24])
    ui4.sit_text_3.setText(msg[24:])
    ui4.money.setText('<p align="center">금액 : '+str(money)+'</p>')
    return msg,str(money)

def sit_click():
    ui4.sit_button.clicked.connect(check)

def day_click(): 
    data=str(ui4.day.selectedDate())[19:]
    data2=data.replace(' ', '')
    day=data2.replace(')', '')
    ui4.Go_text_2.setText('<p align="center">선택 : '+day+'</p>')
    return str(day)
       
def text():
    start=ui4.start_text.toPlainText()
    end=ui4.end_text.toPlainText()
    day=day_click()
    sit,money=check()
    update(day,str(start),str(end),sit,money,list1,id)
    confirm(day,start,end,sit,money,MainWindow)

def search(data):
    money=0
    ui4.sit_text.setText('좌석 : '+data[:9])
    ui4.sit_text_2.setText(data[9:24])
    ui4.sit_text_3.setText(data[24:])
    data2=data.split(',')
    for i in data2:
        if i=='A1':
            ui4.A1.toggle()
            money+=10000
        if i=='A2':
            ui4.A2.toggle()
            money+=10000
        if i=='A3':
            ui4.A3.toggle()
            money+=10000
        if i=='A4':
            ui4.A4.toggle()
            money+=10000
        if i=='B1':
            ui4.B1.toggle()
            money+=10000
        if i=='B2':
            ui4.B2.toggle()
            money+=10000
        if i=='B3':
            ui4.B3.toggle()
            money+=10000
        if i=='B4':
            ui4.B4.toggle()
            money+=10000
        if i=='C1':
            ui4.C1.toggle()
            money+=10000
        if i=='C2':
            ui4.C2.toggle()
            money+=10000
        if i=='C3':
            ui4.C3.toggle()
            money+=10000
        if i=='C4':
            ui4.C4.toggle()
            money+=10000
        if i=='D1':
            ui4.D1.toggle()
            money+=10000
        if i=='D2':
            ui4.D2.toggle()
            money+=10000
        if i=='D3':
            ui4.D3.toggle()
            money+=10000
        if i=='D4':
            ui4.D4.toggle()
            money+=10000
    ui4.money.setText('<p align="center">금액 : '+str(money)+'</p>')

def delet():
    delete(list1,id)
    
def confirm(day,start,end,sit,money,window):
    ui2 = Ui_Confirm()
    ui2.setupUi(window)
    ui2.go.setText('<p align="center">출발일 : '+day+'</p>')
    ui2.start.setText('<p align="center">출발지 : '+start+'</p>')
    ui2.finsh.setText('<p align="center">도착지 : '+end+'</p>')
    ui2.sit.setText('<p align="center">좌석: '+sit+'</p>')
    ui2.money.setText('<p align="center">금액 : '+money+'</p>')
    ui2.ok.clicked.connect(MainWindow.close)
    window.show()
    
def mod(list1):
    ui4.setupUi(MainWindow)
    ui4.Go_text.setText('<p align="center">이전 : '+str(list1[0])+'</p>')
    ui4.start_text.setText(list1[1])
    ui4.end_text.setText(list1[2])
    search(list1[3])
    ui4.A1.stateChanged.connect(sit_click)
    ui4.A2.stateChanged.connect(sit_click)
    ui4.A3.stateChanged.connect(sit_click)
    ui4.A4.stateChanged.connect(sit_click)
    ui4.B1.stateChanged.connect(sit_click)
    ui4.B2.stateChanged.connect(sit_click)
    ui4.B3.stateChanged.connect(sit_click)
    ui4.B4.stateChanged.connect(sit_click)
    ui4.C1.stateChanged.connect(sit_click)
    ui4.C2.stateChanged.connect(sit_click)
    ui4.C3.stateChanged.connect(sit_click)
    ui4.C4.stateChanged.connect(sit_click)
    ui4.D1.stateChanged.connect(sit_click)
    ui4.D2.stateChanged.connect(sit_click)
    ui4.D3.stateChanged.connect(sit_click)
    ui4.D4.stateChanged.connect(sit_click)
    ui4.day.clicked.connect(day_click)
    ui4.mod.clicked.connect(text)
    ui4.cancel.clicked.connect(delet)
    ui4.cancel.clicked.connect(MainWindow.close)

if __name__ == '__main__':
    ui3.setupUi(MainWindow)   
    table()
    MainWindow.show()
    sys.exit(app.exec_())

        