from ui.bus_Ticket_ui import *
from ui.bus_con_ui import *
import sys
from db.db_Ticket import *
from PyQt5.QtCore import QCoreApplication

app = QtWidgets.QApplication(sys.argv)
Window = QtWidgets.QMainWindow()
ui=Ui_busticket()
ui2 = Ui_Confirm()

id=''

def check():
    msg=''
    money=0
    if ui.A1.isChecked()==True:
        msg+='A1,'
        money+=10000
    if ui.A2.isChecked()==True:
        msg+='A2,'
        money+=10000
    if ui.A3.isChecked()==True:
        msg+='A3,'
        money+=10000
    if ui.A4.isChecked()==True:
        msg+='A4,'
        money+=10000
    if ui.B1.isChecked()==True:
        msg+='B1,'
        money+=10000
    if ui.B2.isChecked()==True:
        msg+='B2,'
        money+=10000
    if ui.B3.isChecked()==True:
        msg+='B3,'
        money+=10000
    if ui.B4.isChecked()==True:
        msg+='B4,'
        money+=10000
    if ui.C1.isChecked()==True:
        msg+='C1,'
        money+=10000
    if ui.C2.isChecked()==True:
        msg+='C2,'
        money+=10000
    if ui.C3.isChecked()==True:
        msg+='C3,'
        money+=10000
    if ui.C4.isChecked()==True:
        msg+='C4,'
        money+=10000
    if ui.D1.isChecked()==True:
        msg+='D1,'
        money+=10000
    if ui.D2.isChecked()==True:
        msg+='D2,'
        money+=10000
    if ui.D3.isChecked()==True:
        msg+='D3,'
        money+=10000
    if ui.D4.isChecked()==True:
        msg+='D4,'
        money+=10000
    ui.sit_text.setText('좌석 : '+msg[:9])
    ui.sit_text_2.setText(msg[9:24])
    ui.sit_text_3.setText(msg[24:])
    ui.money.setText('<p align="center">금액 : '+str(money)+'</p>')
    return str(msg),str(money)

def sit_click():
    ui.sit_button.clicked.connect(check)

def day_click(): 
    data=str(ui.day.selectedDate())[19:]
    data2=data.replace(' ', '')
    day=data2.replace(')', '')
    ui.Go_text.setText('<p align="center">선택 : '+day+'</p>')
    return str(day)
       
def text():
    start=ui.start_text.toPlainText()
    end=ui.end_text.toPlainText()
    day=day_click()
    sit,money=check()
    insert(day,str(start),str(end),sit,money,id)
    confirm(day,start,end,sit,money,Window)       
 
def confirm(day,start,end,sit,money,window):
    ui2.setupUi(window)
    ui2.go.setText('<p align="center">출발일 : '+day+'</p>')
    ui2.start.setText('<p align="center">출발지 : '+start+'</p>')
    ui2.finsh.setText('<p align="center">도착지 : '+end+'</p>')
    ui2.sit.setText('<p align="center">좌석: '+sit+'</p>')
    ui2.money.setText('<p align="center">금액 : '+money+'</p>')
    ui2.ok.clicked.connect(Window.close)
    window.show()
    
def main(uid):
    global id
    id=uid
    ui.A1.stateChanged.connect(sit_click)
    ui.A2.stateChanged.connect(sit_click)
    ui.A3.stateChanged.connect(sit_click)
    ui.A4.stateChanged.connect(sit_click)
    ui.B1.stateChanged.connect(sit_click)
    ui.B2.stateChanged.connect(sit_click)
    ui.B3.stateChanged.connect(sit_click)
    ui.B4.stateChanged.connect(sit_click)
    ui.C1.stateChanged.connect(sit_click)
    ui.C2.stateChanged.connect(sit_click)
    ui.C3.stateChanged.connect(sit_click)
    ui.C4.stateChanged.connect(sit_click)
    ui.D1.stateChanged.connect(sit_click)
    ui.D2.stateChanged.connect(sit_click)
    ui.D3.stateChanged.connect(sit_click)
    ui.D4.stateChanged.connect(sit_click)
    ui.day.clicked.connect(day_click)
    ui.ok.clicked.connect(text)
    ui.cancel.clicked.connect(Window.close)    

if __name__ == '__main__':
    ui.setupUi(Window)
    
    main()

    Window.show()
    sys.exit(app.exec_())