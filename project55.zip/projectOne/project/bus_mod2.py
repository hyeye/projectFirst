from ui.bus_mod_ui import *
from ui.bus_con_ui import *
from ui.bus_list_ui import *
from db.db_list import *
from db.db_mod import *
from PyQt5.QtCore import QCoreApplication
from PyQt5.Qt import QTableWidgetItem, Qt
import sys

class main_mod():
    list=[] 
    ui3 = Ui_buslist()
    ui4 = Ui_busmod()  
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    
    def __init__(self):
        self.ui3.setupUi(self.MainWindow)
        self.table()
        self.MainWindow.show()
        sys.exit(self.app.exec_())
        
    def table(self):
        header = self.ui3.table.horizontalHeader()       
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)
        header.setSectionResizeMode(4, QtWidgets.QHeaderView.Stretch) 
        
        self.ui3.table.setRowCount(0)
        
        for row, form in enumerate(select_all()):
            row_position=self.ui3.table.rowCount()
            self.ui3.table.insertRow(row_position)        
            for column,value in enumerate(form):
                item = QTableWidgetItem(str(value))
                item.setTextAlignment(Qt.AlignVCenter | Qt.AlignHCenter);
                self.ui3.table.setItem(row,column,item)
                self.ui3.table.setEditTriggers(QtWidgets.QTableWidget.NoEditTriggers)
                
        self.ui3.table.cellClicked.connect(self.updateMore)
        self.ui3.ok.clicked.connect(self.click)
        self.ui3.cancel.clicked.connect(QCoreApplication.instance().quit)
        
    def updateMore(self):
        list=[]
        row=self.ui3.table.currentItem().row()
        for i in range(self.ui3.table.columnCount()):
            list.append(self.ui3.table.item(row, i).text())
        return list
    
    def click(self):    
        i=self.updateMore()
        list=select(i[0],i[1],i[2],i[3],i[4])
        self.mod(list)
    
    def check(self):
        msg=''
        money=0
        if self.ui4.A1.isChecked()==True:
            msg+='A1,'
            money+=10000
        if self.ui4.A2.isChecked()==True:
            msg+='A2,'
            money+=10000
        if self.ui4.A3.isChecked()==True:
            msg+='A3,'
            money+=10000
        if self.ui4.A4.isChecked()==True:
            msg+='A4,'
            money+=10000
        if self.ui4.B1.isChecked()==True:
            msg+='B1,'
            money+=10000
        if self.ui4.B2.isChecked()==True:
            msg+='B2,'
            money+=10000
        if self.ui4.B3.isChecked()==True:
            msg+='B3,'
            money+=10000
        if self.ui4.B4.isChecked()==True:
            msg+='B4,'
            money+=10000
        if self.ui4.C1.isChecked()==True:
            msg+='C1,'
            money+=10000
        if self.ui4.C2.isChecked()==True:
            msg+='C2,'
            money+=10000
        if self.ui4.C3.isChecked()==True:
            msg+='C3,'
            money+=10000
        if self.ui4.C4.isChecked()==True:
            msg+='C4,'
            money+=10000
        if self.ui4.D1.isChecked()==True:
            msg+='D1,'
            money+=10000
        if self.ui4.D2.isChecked()==True:
            msg+='D2,'
            money+=10000
        if self.ui4.D3.isChecked()==True:
            msg+='D3,'
            money+=10000
        if self.ui4.D4.isChecked()==True:
            msg+='D4,'
            money+=10000
        self.ui4.sit_text.setText('좌석 : '+msg[:9])
        self.ui4.sit_text_2.setText(msg[9:24])
        self.ui4.sit_text_3.setText(msg[24:])
        self.ui4.money.setText('<p align="center">금액 : '+str(money)+'</p>')
        return msg,str(money)
    
    def sit_click(self):
        self.ui4.sit_button.clicked.connect(self.check)
    
    def day_click(self): 
        data=str(self.ui4.day.selectedDate())[19:]
        data2=data.replace(' ', '')
        day=data2.replace(')', '')
        self.ui4.Go_text_2.setText('<p align="center">선택 : '+day+'</p>')
        return str(day)
           
    def text(self):
        start=self.ui4.start_text.toPlainText()
        end=self.ui4.end_text.toPlainText()
        day=self.day_click()
        sit,money=self.check()
        update(day,str(start),str(end),sit,money,list[0],list[1],list[2],list[3],list[4])
        self.confirm(day,start,end,sit,money,self.MainWindow)
    
    def search(self,data):
        money=0
        self.ui4.sit_text.setText('좌석 : '+data[:9])
        self.ui4.sit_text_2.setText(data[9:24])
        self.ui4.sit_text_3.setText(data[24:])
        data2=data.split(',')
        for i in data2:
            if i=='A1':
                self.ui4.A1.toggle()
                money+=10000
            if i=='A2':
                self.ui4.A2.toggle()
                money+=10000
            if i=='A3':
                self.ui4.A3.toggle()
                money+=10000
            if i=='A4':
                self.ui4.A4.toggle()
                money+=10000
            if i=='B1':
                self.ui4.B1.toggle()
                money+=10000
            if i=='B2':
                self.ui4.B2.toggle()
                money+=10000
            if i=='B3':
                self.ui4.B3.toggle()
                money+=10000
            if i=='B4':
                self.ui4.B4.toggle()
                money+=10000
            if i=='C1':
                self.ui4.C1.toggle()
                money+=10000
            if i=='C2':
                self.ui4.C2.toggle()
                money+=10000
            if i=='C3':
                self.ui4.C3.toggle()
                money+=10000
            if i=='C4':
                self.ui4.C4.toggle()
                money+=10000
            if i=='D1':
                self.ui4.D1.toggle()
                money+=10000
            if i=='D2':
                self.ui4.D2.toggle()
                money+=10000
            if i=='D3':
                self.ui4.D3.toggle()
                money+=10000
            if i=='D4':
                self.ui4.D4.toggle()
                money+=10000
        self.ui4.money.setText('<p align="center">금액 : '+str(money)+'</p>')
    
    def delet(self):
        delete(list[0],list[1],list[2],list[3],list[4])
        
    def confirm(self,day,start,end,sit,money,window):
        ui2 = Ui_Confirm()
        ui2.setupUi(window)
        ui2.go.setText('<p align="center">출발일 : '+day+'</p>')
        ui2.start.setText('<p align="center">출발지 : '+start+'</p>')
        ui2.finsh.setText('<p align="center">도착지 : '+end+'</p>')
        ui2.sit.setText('<p align="center">좌석: '+sit+'</p>')
        ui2.money.setText('<p align="center">금액 : '+money+'</p>')
        ui2.ok.clicked.connect(QCoreApplication.instance().quit)
        window.show()
        
    def mod(self,list):
        self.ui4.setupUi(self.MainWindow)
        self.ui4.Go_text.setText('<p align="center">이전 : '+str(list[0])+'</p>')
        self.ui4.start_text.setText(list[1])
        self.ui4.end_text.setText(list[2])
        self.search(list[3])
        
        self.ui4.A1.stateChanged.connect(self.sit_click)
        self.ui4.A2.stateChanged.connect(self.sit_click)
        self.ui4.A3.stateChanged.connect(self.sit_click)
        self.ui4.A4.stateChanged.connect(self.sit_click)
        self.ui4.B1.stateChanged.connect(self.sit_click)
        self.ui4.B2.stateChanged.connect(self.sit_click)
        self.ui4.B3.stateChanged.connect(self.sit_click)
        self.ui4.B4.stateChanged.connect(self.sit_click)
        self.ui4.C1.stateChanged.connect(self.sit_click)
        self.ui4.C2.stateChanged.connect(self.sit_click)
        self.ui4.C3.stateChanged.connect(self.sit_click)
        self.ui4.C4.stateChanged.connect(self.sit_click)
        self.ui4.D1.stateChanged.connect(self.sit_click)
        self.ui4.D2.stateChanged.connect(self.sit_click)
        self.ui4.D3.stateChanged.connect(self.sit_click)
        self.ui4.D4.stateChanged.connect(self.sit_click)
        self.ui4.day.clicked.connect(self.day_click)
    
        self.ui4.mod.clicked.connect(self.text)
        self.ui4.cancel.clicked.connect(self.delet)
        self.ui4.cancel.clicked.connect(QCoreApplication.instance().quit)

if __name__ == '__main__':
    a=main_mod()
    a.__init__()

        