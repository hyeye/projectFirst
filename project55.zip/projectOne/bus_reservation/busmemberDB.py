import pymysql

con = None

global uid, pw, pwcheck, name, birth, tel, email

global login_id

uid, pw = None, None


# 회원가입완료 누를때 사용
def db_memberInsert(uid, pw, pwcheck, name, birth, tel, email):
    '''1. DB인증 -> 연결'''
    con = pymysql.connect(host = 'localhost', user = 'root', password = '1234', db = 'busreservation')
    '''2. 연결정보 -> 통로'''
    cur = con.cursor()
    ''''3. sql문 만들어서 -> 전송'''
    sql = "insert into busmember values ('%s', '%s', '%s', '%s', %d, '%s', '%s')"%(uid, pw, pwcheck, name, birth, tel, email)
    cur.execute(sql)
    con.commit()
    '''4. 연결해제'''
    con.close()
    
# 회원가입페이지 - 아이디 중복확인시 사용
def db_IDcheck():
    
    con = pymysql.connect(host = 'localhost', user = 'root', password = '1234', db = 'busreservation')
    cur = con.cursor()
    sql = "select uid from busmember"
    n = cur.execute(sql)
#     con.commit()
    
    IDresult = []
    
    while True:
        record = cur.fetchone()
        if record == None:
            break
        else:
#             print(record)
            IDresult.append(record)
    
#     print(IDresult)

    con.close()

    return IDresult
    




# 마이페이지 - 회원탈퇴시 사용
def db_memberDelete(uid, pw):

    con = pymysql.connect(host = 'localhost', user = 'root', password = '1234', db = 'busreservation')
    cur = con.cursor()
    sql = "delete from busmember where uid = '%s' and pw = '%s'"%(uid, pw)
    cur.execute(sql)
    con.commit()
    con.close()


# 마이페이지 - 회원수정시 사용
def db_memberUpdate(uid, pw, pwcheck, name, birth, tel, email):
    
    con = pymysql.connect(host = 'localhost', user = 'root', password = '1234', db = 'busreservation')
    cur = con.cursor()
    sql = "update busmember set pw = '%s', pwcheck = '%s', birth = %d, tel = '%s' , email = '%s' where uid = '%s'"%(pw, pwcheck, birth, tel, email, uid)
    cur.execute(sql)
    con.commit()
    con.close()

# 마이페이지 - 회원수정페이지 불러오기
# def db_mypage_select(uid):
#     con = pymysql.connect(host = 'localhost', user = 'root', password = '1234', db = 'busreservation')
#     cur = con.cursor()
#     sql ="select pw, pwcheck, name, birth, tel, email from busmember where uid = '%s'" % uid
#     result = cur.execute(sql)
#     record = cur.fetchone()
#     return record
#     con.close()
#     
#     while True:
#         row = cur.fetchone()
#         if row == None:
#             break;
#         data1 = row[0]
#         data2 = row[1]
#         data3 = row[2]
#         data4 = row[3]
#         data5 = row[4]
#         data6 = row[5]
#          
#     print("[SELECT] %d건 완료" %result)
#      
#     return (data1, data2, data3, data4, data5, data6)

# 마이페이지 - 회원수정페이지 불러오기
def db_mypage_select(uid):

    con = pymysql.connect(host = 'localhost', user = 'root', password = '1234', db = 'busreservation')
    cur = con.cursor()
    sql ="select * from busmember where uid = '%s'" % uid
    cur.execute(sql)
#     record = cur.fetchone()
    con.close()
    info_list = []
    while True:
        row = cur.fetchone()
        if row == None:
            break;
        info_list.append(row)
#         data1 = row[0]
#         data2 = row[1]
#         data3 = row[2]
#         data4 = row[3]
#         data5 = row[4]
#         data6 = row[5]
         
#     print("[SELECT] %d건 완료" %result)
     
#     return record
#     return (data1, data2, data3, data4, data5, data6)
    print(info_list)
    return info_list




# 아이디찾기시 사용
def db_memberSelectID(name, email):

    con = pymysql.connect(host = 'localhost', user = 'root', password = '1234', db = 'busreservation')
    cur = con.cursor()
    sql = "select uid from busmember where name = '%s' and email = '%s'"%(name, email)
    cur.execute(sql) 
    idrecord = cur.fetchone()
    return idrecord
    con.close()

# 비밀번호찾기시 사용   
def db_memberSelectPW(uid, email):

    con = pymysql.connect(host = 'localhost', user = 'root', password = '1234', db = 'busreservation')
    cur = con.cursor()
    sql = "select pw from busmember where uid = '%s' and email = '%s'"%(uid, email)
    cur.execute(sql) 
    pwrecord = cur.fetchone()
    return pwrecord
    con.close()


# # 로그인할 때 사용    
# def db_memberLogin(uid):
#     
#     con = pymysql.connect(host = 'localhost', user = 'root', password = '1234', db = 'busreservation')
#     cur = con.cursor()
#     sql = "select uid, pw from busmember where uid = '%s'" % uid
#     cur.execute(sql) 
#     record = cur.fetchone()
#     return record
#     con.close()

# # 로그인할 때 사용    
# def db_memberLogin(uid):
#       
#     con = pymysql.connect(host = 'localhost', user = 'root', password = '1234', db = 'busreservation')
#     cur = con.cursor()
#     sql = "select * from busmember where uid = '%s'" % uid
#     cur.execute(sql) 
#     record = cur.fetchone()
#     con.close()
#  
# #     print(record)
#  
#     return record

# 로그인할 때 사용    
def db_memberLogin(login_id):
      
    con = pymysql.connect(host = 'localhost', user = 'root', password = '1234', db = 'busreservation')
    cur = con.cursor()
    sql = "select * from busmember where uid = '%s'" % login_id
    cur.execute(sql) 
    record = cur.fetchone()
    con.close()
  
#     print(record)
  
    return record


# 회원가입 수정 - 전체 목록뽑기.
def db_memberSelectall(uid):
    con = pymysql.connect(host = 'localhost', user = 'root', password = '1234', db = 'busreservation')

    cur = con.cursor()

    
    sql = "select * from busmember where uid = '%s'" % uid
    n = cur.execute(sql)
#     con.commit()
    
    result = []
    
    while True:
        record = cur.fetchone()
        if record == None:
            break
        else:
#             print(record)
            result.append(record)
    
#     print(result)

    con.close()

    return result

# 회원탈퇴 - 목록불러오기.
def db_memberSelectpd(uid):
    con = pymysql.connect(host = 'localhost', user = 'root', password = '1234', db = 'busreservation')

    cur = con.cursor()

    
    sql = "select uid,pw from busmember where uid = '%s'" % uid
    n = cur.execute(sql)
#     con.commit()
    
    delresult = []
    
    while True:
        record = cur.fetchone()
        if record == None:
            break
        else:
#             print(record)
            delresult.append(record)
    
#     print(delresult)

    con.close()

    return delresult

# uid, pw, pwcheck, name, birth, tel, email

if __name__ == '__main__':
    mydel_list = db_memberSelectpd('test')
    print(mydel_list)