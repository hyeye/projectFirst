# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '.\bus_con.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Confirm(object):
    def setupUi(self, Confirm):
        Confirm.setObjectName("Confirm")
        Confirm.resize(687, 311)
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(16)
        font.setBold(True)
        font.setWeight(75)
        Confirm.setFont(font)
        self.centralwidget = QtWidgets.QWidget(Confirm)
        self.centralwidget.setObjectName("centralwidget")
        self.ok = QtWidgets.QPushButton(self.centralwidget)
        self.ok.setGeometry(QtCore.QRect(300, 220, 121, 51))
        self.ok.setObjectName("ok")
        self.money = QtWidgets.QLabel(self.centralwidget)
        self.money.setGeometry(QtCore.QRect(10, 160, 671, 51))
        font = QtGui.QFont()
        font.setPointSize(28)
        font.setBold(False)
        font.setWeight(50)
        self.money.setFont(font)
        self.money.setObjectName("money")
        self.go = QtWidgets.QLabel(self.centralwidget)
        self.go.setGeometry(QtCore.QRect(10, 10, 671, 21))
        self.go.setObjectName("go")
        self.start = QtWidgets.QLabel(self.centralwidget)
        self.start.setGeometry(QtCore.QRect(10, 50, 671, 31))
        self.start.setObjectName("start")
        self.finsh = QtWidgets.QLabel(self.centralwidget)
        self.finsh.setGeometry(QtCore.QRect(10, 90, 671, 31))
        self.finsh.setObjectName("finsh")
        self.sit = QtWidgets.QLabel(self.centralwidget)
        self.sit.setGeometry(QtCore.QRect(10, 130, 671, 21))
        self.sit.setObjectName("sit")
        Confirm.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Confirm)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 687, 21))
        self.menubar.setObjectName("menubar")
        Confirm.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Confirm)
        self.statusbar.setObjectName("statusbar")
        Confirm.setStatusBar(self.statusbar)

        self.retranslateUi(Confirm)
        QtCore.QMetaObject.connectSlotsByName(Confirm)

    def retranslateUi(self, Confirm):
        _translate = QtCore.QCoreApplication.translate
        Confirm.setWindowTitle(_translate("Confirm", "정상적으로 처리 되었습니다."))
        self.ok.setText(_translate("Confirm", "확인"))
        self.money.setText(_translate("Confirm", "<html><head/><body><p align=\"center\">금액 : *******</p></body></html>"))
        self.go.setText(_translate("Confirm", "<html><head/><body><p align=\"center\">출발일 : ****/**/**</p><p align=\"center\">출발지 : ***</p><p align=\"center\">도착지 : ***</p><p align=\"center\">좌석 : **</p></body></html>"))
        self.start.setText(_translate("Confirm", "<html><head/><body><p align=\"center\">출발지 : ***</p><p align=\"center\">도착지 : ***</p><p align=\"center\">좌석 : **</p></body></html>"))
        self.finsh.setText(_translate("Confirm", "<html><head/><body><p align=\"center\">도착지 : ***</p></body></html>"))
        self.sit.setText(_translate("Confirm", "<html><head/><body><p align=\"center\">좌석 : **</p></body></html>"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Confirm = QtWidgets.QMainWindow()
    ui = Ui_Confirm()
    ui.setupUi(Confirm)
    Confirm.show()
    sys.exit(app.exec_())

