import pymysql

def connect(sql):
    con=pymysql.connect(host='localhost',
                    user='root',
                    password='1234',
                    db='busreservation',
                    charset='utf8')
    cur=con.cursor()
    cur.execute(sql)
    con.commit()
    con.close()

def delete(list,id):
    sql = "delete from bus where godate='{}' and startpoint='{}' and finshpoint='{}' and sit='{}' and money='{}' and id='{}'".format(list[0],list[1],list[2],list[3],list[4],id)
    connect(sql)
#     print('삭제완료...')
    
def select(lists,id): 
    list=[]
    con=pymysql.connect(host='localhost',user='root',password='1234',db='busreservation',charset='utf8') 
    cur=con.cursor()
    sql = "select * from bus where godate='{}'and startpoint='{}'and finshpoint='{}'and sit='{}'and money ='{}' and id = '{}'".format(lists[0],lists[1],lists[2],lists[3],lists[4],id)
    cur.execute(sql)
    recode=cur.fetchone()
    for i in recode:
        list.append(i)
    con.commit()
    con.close()
    return list
    
def update(godata,startpoint,finshpoint,sit,money,list,id):    
    sql = "update bus set godate='{}', startpoint='{}', finshpoint='{}', sit='{}', money='{}' where godate='{}' and startpoint='{}' and finshpoint='{}' and sit='{}' and money='{}' and id='{}'".format(godata,startpoint,finshpoint,sit,money,list[0],list[1],list[2],list[3],list[4],id)
    connect(sql)
#     print('수정완료...')
    
if __name__ == '__main__':
    pass