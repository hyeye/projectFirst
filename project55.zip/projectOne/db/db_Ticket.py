import pymysql

def connect(sql):
    con=pymysql.connect(host='localhost',
                    user='root',
                    password='1234',
                    db='busreservation',
                    charset='utf8')
    cur=con.cursor()
    cur.execute(sql)
    con.commit()
    con.close()
    
def insert(godata,startpoint,finshpoint,sit,money,id): 
    sql = "insert into bus values('{}','{}','{}','{}','{}','{}')".format(godata,startpoint,finshpoint,sit,money,id)
    connect(sql)
#     print('등록완료...')

if __name__ == '__main__':
    pass