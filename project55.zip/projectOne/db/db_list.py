import pymysql

def select_all(id): 
    lists=[]
    con=pymysql.connect(host='localhost',user='root',password='1234',db='busreservation',charset='utf8') 
    cur=con.cursor()
    sql = "select * from bus where id = '{}'".format(id)
    cur.execute(sql)
    tuples=cur.fetchall()
    con.commit()
    con.close()
    return tuples

if __name__ == '__main__':
    print(select_all())